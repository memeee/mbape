NodeJS Backend for Webix File Manager
==================

### How to start

Serve local files, absolute path is required.

```shell script
npm install

# windows
npm run local D:\\some\\folder

# linux
npm run local /media/user/d/some/folder
```

Note that you need to use NodeJS v12.3.0 or higher to be able to write into text files.

